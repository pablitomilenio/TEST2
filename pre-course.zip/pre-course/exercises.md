# exercises

There are two exercises: Underline and Stringifier (go through them in this order).

For each exercise you find a separate folder in this repository, containing a readme file with instructions.

## Help

Whenever you’re stuck, feel free to look for information online (e.g. checking docs on [MDN](https://developer.mozilla.org/en/docs/Web), or reading answers on [Stack Overflow](http://stackoverflow.com/)). Make sure you don’t search for the entire exercise solution, as this would obviously defeat the course purpose.

For example, when you’re implementing the `_.each()` function in Underline you might search online for information like “js iterate over object ignoring prototype“, but not things like “js how to implement each“.

For the same reason obviously you’re not supposed to look up / copy the source code from an existing library, or from solutions implemented by other students.

On the other hand, you’re more than welcome to interact with fellow students and instructors, posting questions on Slack.

## Setting up your environment

To be able to do the exercises, you need to have the following software installed on your computer. Here we provide instructions for Mac computers, using the native Terminal app or [Hyper](https://hyper.is/).

If you have Windows or Linux, search instructions on Google to figure out how to proceed.

### Terminal

Install [Homebrew](http://brew.sh/) and [oh-my-zsh](https://ohmyz.sh/).

### Git

Set up [authentication](https://help.github.com/en/github/getting-started-with-github/set-up-git#next-steps-authenticating-with-github-from-git).

If you’re working with a Windows system run `git config --global core.autocrlf false`.

### Node

Install [nvm](https://github.com/creationix/nvm), close your terminal window and open it again. Type `nvm install node`.

### Gulp

Once Node is properly installed on your computer, to install [Gulp](http://gulpjs.com/) just type `npm install -g gulp-cli`.

### Markdown

All the docs are written in [Markdown](https://guides.github.com/features/mastering-markdown/) format. If you’re not familiar with it yet, take a few minutes to figure out how it works (it should be quite easy for you at this point). Then install an editor / viewer on your computer, so you can enjoy a nicer formatting. Our favorite one is [Typora](https://www.typora.io/).

### Code editor

Set up your editor to indent with 2 spaces, and remove trailing whitespace. Then follow our [coding style guide](https://github.com/codeworks/style-guide).

If you’re working with a Windows system, make sure the editor is set up to use Unix [line endings](https://en.wikipedia.org/wiki/Newline) by default before you open and save any repo file (otherwise it will generate many errors in the linter when you try to commit your work).

## Start coding

Ok, you should be ready to start coding! Navigate to the home folder of Underline on your local computer (e.g. `cd underline`), and follow the instructions in the readme there.
